/* 
		
			Elevmail: mmm223kk@student.lnu.se
			
			Namn: Sami Mwanje.                     */

package mm223kk_lab4.stack;

import java.util.*;
import java.util.Iterator;

public class Stackimplement implements Stack {
	
	// Varibaler.

	private Object[] stack = new Object [0];
	private Object[] stackCopy = new Object[0];
	private Object top;
	List<Object> list;
	Iterator<Object> iter;
	
	// Current stack size

	public int size() {
	return stackCopy.length;	 // Stackens längd.
	}
	
	// True if stack is empty.
	
	public boolean isEmpty() {
		
		if(stackCopy.length == 0) { // Kontroll om tom.
			return true;
		}
		else 
			return false;
	}
	

	// Add element at top of stack
	
	public void push(Object element) {

		if(size() != 0) {
			stackCopy = stack; // Kopia av vår äldre stack.
		}
			stack = new Object [stackCopy.length+1]; // Ökar stackens storlek.
			
		if(size() != 0) {  // Inför våra element i den nya stacken.
		for(int i = 0; i < stackCopy.length; i++) {
			stack[i] = stackCopy[i];
		}
		
		}
		
		stack[stackCopy.length] = element; // Inför nya elementet.
		
		list = Arrays.asList(stackCopy); // Uppdaterar vår lista.
		iter = list.iterator();
		
		stackCopy = stack; // Gör en kopia av vår nya stack.
		}
	
	// Return and remove top element,	 exception if stack is empty.
		
	public Object pop() {
		
		if ( size() == 0) {                   // om stacken är tom.
		throw new EmptyStackException();
		}
		
			top = stackCopy[stackCopy.length-1]; // Sparar toppelementet som ska raderas.
			stack = new Object [stackCopy.length-1]; // Minskar stackens storlek.
			
		if(size() != 1) {
				
		for(int i = 0; i < stackCopy.length-1; i++) { // Lägger till dem tidigare elementen förutom sista.
				stack[i] = stackCopy[i];
			}
		
		}
			stackCopy = stack; // Gör en kopia av vår nya stack.
			
			list = Arrays.asList(stackCopy); // Uppdaterar vår lista.
			iter = list.iterator();
			
			return top;	// Ger oss det raderade toppelementet. 
		}
	
		
	// Return (without removing) top element,
	
	public Object peek() {
		
		if ( size() == 0)	
			throw new EmptyStackException();

		return stackCopy[stackCopy.length-1]; // Ger oss toppelementet.
	
	}
	
		public Iterator<Object> iterator() {
		
		return iter; }
}