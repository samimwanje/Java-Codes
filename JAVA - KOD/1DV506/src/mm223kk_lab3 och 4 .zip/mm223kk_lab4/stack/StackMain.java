/* 
		
			Elevmail: mmm223kk@student.lnu.se
			
			Namn: Sami Mwanje.                     */

package mm223kk_lab4.stack;

public class StackMain {

		public static void main(String[] args) {
	
			Stackimplement stack = new Stackimplement();
			
			// Skapar fyra nya objekt...
 
			String S1 = "Objekt 1";
			String S2 = "Objekt 2";
			String S3 = "Objekt 3";
			String S4 = "Objekt 4";
			
			// Lägg till objekt...

			stack.push(S1);
			stack.push(S2);
			stack.push(S3);
			stack.push(S4);
			
			// Utför lite metoder...
			
			System.out.println("Stackens storlek: " + stack.size());
			System.out.println("Stacken tom: " + stack.isEmpty());
			System.out.println("Ta bort: " + stack.pop());
			System.out.println("Ta bort: " + stack.pop());
			System.out.println("Stackens storlek: " + stack.size());
			System.out.println("Stackens topp: " + stack.peek());
			
			
			// Printar ut alla stackens element med iterator.
			
			System.out.println("Stackens element: "); 
			
			while (stack.iterator().hasNext()) {
			
			System.out.println(stack.iterator().next() +" ");
				 
			 }
	}
}
